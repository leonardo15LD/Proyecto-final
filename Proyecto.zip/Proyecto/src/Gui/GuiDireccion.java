/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

/**
 *
 * @author LEONARDO ACUÑA
 */
public class GuiDireccion extends JDialog{
    private final JPanel contentPanel = new JPanel();
    private JTextField txtVivienda;
    
    private JTextField txtLocalidad;
    private JTextField txtCiudad;
    private JTextField txtDepa;
    private JTextField txtPais;
    private JTextField txtCaract;
    private JTable tbLista;

    /**
     * Launch the application.
     *
     * @param args
     */
    public static void main(String[] args) {
        try
        {
            GuiDireccion dialog = new GuiDireccion();
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            dialog.setVisible(true);

        } catch (Exception e)
        {
        }
    }

    /**
     * Create the dialog.
     */
    public GuiDireccion() {
        setBounds(100, 100, 1020, 500);
        getContentPane().setLayout(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        getContentPane().add(contentPanel, BorderLayout.CENTER);
        contentPanel.setLayout(null);
        {
            JPanel panel = new JPanel();
            panel.setLayout(null);
            panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Datos de Ultima Direccion", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
            panel.setBounds(10, 55, 239, 390);
            contentPanel.add(panel);
            {
                txtVivienda = new JTextField();
                txtVivienda.setColumns(10);
                txtVivienda.setBounds(132, 24, 92, 20);
                panel.add(txtVivienda);
            }
            {
                JLabel lblNewLabel_3 = new JLabel("Numero Vivienda");
                lblNewLabel_3.setBounds(10, 27, 96, 14);
                panel.add(lblNewLabel_3);
            }
            {
                JLabel lblNewLabel_4 = new JLabel("localidad");
                lblNewLabel_4.setBounds(10, 68, 112, 14);
                panel.add(lblNewLabel_4);
            }
          
            {
                JLabel lblNewLabel_6 = new JLabel("ciudad");
                lblNewLabel_6.setBounds(10, 106, 112, 14);
                panel.add(lblNewLabel_6);
            }
            {
                JLabel lblNewLabel_7 = new JLabel("Departamento");
                lblNewLabel_7.setBounds(10, 147, 162, 14);
                panel.add(lblNewLabel_7);
            }
            {
                JLabel lblNewLabel_7 = new JLabel("Pais");
                lblNewLabel_7.setBounds(10, 188, 212, 14);
                panel.add(lblNewLabel_7);
            }
            {
                JLabel lblNewLabel_8 = new JLabel("Caracteristicas");
                lblNewLabel_8.setBounds(10, 229, 262, 14);
                panel.add(lblNewLabel_8);
            }

            {
                txtLocalidad = new JTextField();
                txtLocalidad.setColumns(10);
                txtLocalidad.setBounds(132, 65, 92, 20);
                panel.add(txtLocalidad);
            }
           
            {
                txtCiudad = new JTextField();
                txtCiudad.setBounds(132, 103, 92, 20);
                txtCiudad.setColumns(10);
                panel.add(txtCiudad);
            }
            {
                txtDepa = new JTextField();
                txtDepa.setBounds(132, 147, 92, 20);
                txtDepa.setColumns(10);
                panel.add(txtDepa);
            }
            {
                txtPais = new JTextField();
                txtPais.setBounds(132, 187, 92, 20);
                txtPais.setColumns(10);
                panel.add(txtPais);
            }
            {
                txtCaract = new JTextField();
                txtCaract.setBounds(132, 227, 92, 50);
                txtCaract.setColumns(10);
                panel.add(txtCaract);
            }

            {
                JButton btnGuardar = new JButton("Guardar");
                btnGuardar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        Modelo.Direccion objeto = new Modelo.Direccion();
                        objeto.setNoVivienda(txtVivienda.getText());
                        objeto.setLocalidad(txtLocalidad.getText());
                        
                        objeto.setCiudad(txtCiudad.getText());
                        objeto.setDepartamento(txtDepa.getText());
                        objeto.setPais(txtPais.getText());
                        objeto.setCaracteristicas(txtCaract.getText());
                        objeto.agregarRegistros();
                    }
                });
                btnGuardar.setBounds(10, 320, 95, 23);
                panel.add(btnGuardar);
            }
            {
                JButton btnEditar = new JButton("Editar");
                btnEditar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        Modelo.Direccion objeto = new Modelo.Direccion();
                        objeto.Editar(tbLista);
                    }
                });
                btnEditar.setBounds(135, 320, 90, 23);
                panel.add(btnEditar);
            }
            {
                JButton btnEliminar = new JButton("Eliminar");
                btnEliminar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        Modelo.Direccion objeto = new Modelo.Direccion();
                        objeto.Eliminar(tbLista, txtVivienda);
                    }
                });
                btnEliminar.setBounds(10, 350, 215, 23);
                panel.add(btnEliminar);
            }

        }
        {
            JPanel panel_1 = new JPanel();
            panel_1.setLayout(null);
            panel_1.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Lista de Direcciones", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
            panel_1.setBounds(259, 55, 730, 390);
            contentPanel.add(panel_1);
            {
                JScrollPane scrollPane = new JScrollPane();
                scrollPane.setBounds(10, 23, 710, 350);
                panel_1.add(scrollPane);
                {
                    tbLista = new JTable();
                    scrollPane.setViewportView(tbLista);
                }
            }
        }
        {
            JButton btnCrearArchivo = new JButton("Crear Archivo ");
            btnCrearArchivo.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Modelo.Direccion objeto = new Modelo.Direccion();
                    objeto.crearArchivo();
                }
            });
            btnCrearArchivo.setBounds(10, 21, 232, 23);
            contentPanel.add(btnCrearArchivo);
        }
        {
            JButton btnMostrar = new JButton("Mostrar Lista de Direcciones");
            btnMostrar.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Modelo.Direccion objeto = new Modelo.Direccion();
                    objeto.MostrarTotal(tbLista);
                }
            });
            btnMostrar.setBounds(261, 21, 234, 23);
            contentPanel.add(btnMostrar);
        }
        {
            JButton btnSeleccionar = new JButton("Seleccionar");
            btnSeleccionar.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Modelo.Direccion objeto = new Modelo.Direccion();

                    objeto.seleccionar(tbLista);
                    txtVivienda.setText(objeto.getNoVivienda());
                    txtCiudad.setText(objeto.getCiudad());
                    txtLocalidad.setText(objeto.getCiudad());
                    txtDepa.setText(objeto.getDepartamento());
                    txtPais.setText(objeto.getPais());
                    txtCaract.setText(objeto.getCaracteristicas());
                    

                }
            });
            btnSeleccionar.setBounds(750, 21, 234, 23);
            contentPanel.add(btnSeleccionar);
        }
    }
}
