/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

/**
 *
 * @author LEONARDO ACUÑA
 */
public class GuiSospechosos extends JDialog {

    private final JPanel contentPanel = new JPanel();
    private JTextField txtId;
    private JTextField txtEdad;
    
    private JTextField txtNombre;
    private JTextField txtApellido;
    private JTextField txtAlias;
    private JTable tbLista;

    /**
     * Launch the application.
     *
     * @param args
     */
    public static void main(String[] args) {
        try
        {
            GuiSospechosos dialog = new GuiSospechosos();
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            dialog.setVisible(true);

        } catch (Exception e)
        {
        }
    }

    /**
     * Create the dialog.
     */
    public GuiSospechosos() {
        setBounds(100, 100, 850, 400);
        getContentPane().setLayout(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        getContentPane().add(contentPanel, BorderLayout.CENTER);
        contentPanel.setLayout(null);
        {
            JPanel panel = new JPanel();
            panel.setLayout(null);
            panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Datos del Sospechoso", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
            panel.setBounds(10, 55, 239, 290);
            contentPanel.add(panel);
            {
                txtId = new JTextField();
                txtId.setColumns(10);
                txtId.setBounds(132, 24, 92, 20);
                panel.add(txtId);
            }
            {
                JLabel lblNewLabel_3 = new JLabel("Id");
                lblNewLabel_3.setBounds(10, 27, 96, 14);
                panel.add(lblNewLabel_3);
            }
            {
                JLabel lblNewLabel_4 = new JLabel("Edad");
                lblNewLabel_4.setBounds(10, 68, 112, 14);
                panel.add(lblNewLabel_4);
            }
          
            {
                JLabel lblNewLabel_6 = new JLabel("Nombre");
                lblNewLabel_6.setBounds(10, 106, 112, 14);
                panel.add(lblNewLabel_6);
            }
            {
                JLabel lblNewLabel_7 = new JLabel("Apellido");
                lblNewLabel_7.setBounds(10, 147, 162, 14);
                panel.add(lblNewLabel_7);
            }
            {
                JLabel lblNewLabel_7 = new JLabel("Alias");
                lblNewLabel_7.setBounds(10, 188, 212, 14);
                panel.add(lblNewLabel_7);
            }

            {
                txtEdad = new JTextField();
                txtEdad.setColumns(10);
                txtEdad.setBounds(132, 65, 92, 20);
                panel.add(txtEdad);
            }
           
            {
                txtNombre = new JTextField();
                txtNombre.setBounds(132, 103, 92, 20);
                txtNombre.setColumns(10);
                panel.add(txtNombre);
            }
            {
                txtApellido = new JTextField();
                txtApellido.setBounds(132, 147, 92, 20);
                txtApellido.setColumns(10);
                panel.add(txtApellido);
            }
            {
                txtAlias = new JTextField();
                txtAlias.setBounds(132, 187, 92, 20);
                txtAlias.setColumns(10);
                panel.add(txtAlias);
            }

            {
                JButton btnGuardar = new JButton("Guardar");
                btnGuardar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        Modelo.Sospechoso objeto = new Modelo.Sospechoso();
                        objeto.setId(txtId.getText());
                        objeto.setEdad(txtEdad.getText());
                        
                        objeto.setNombre(txtNombre.getText());
                        objeto.setApellido(txtApellido.getText());
                        objeto.setAlias(txtAlias.getText());
                        objeto.agregarRegistros();
                    }
                });
                btnGuardar.setBounds(10, 220, 95, 23);
                panel.add(btnGuardar);
            }
            {
                JButton btnEditar = new JButton("Editar");
                btnEditar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        Modelo.Sospechoso objeto = new Modelo.Sospechoso();
                        objeto.Editar(tbLista);
                    }
                });
                btnEditar.setBounds(135, 220, 90, 23);
                panel.add(btnEditar);
            }
            {
                JButton btnEliminar = new JButton("Eliminar");
                btnEliminar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        Modelo.Sospechoso objeto = new Modelo.Sospechoso();
                        objeto.Eliminar(tbLista, txtId);
                    }
                });
                btnEliminar.setBounds(10, 250, 215, 23);
                panel.add(btnEliminar);
            }

        }
        {
            JPanel panel_1 = new JPanel();
            panel_1.setLayout(null);
            panel_1.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Lista de Sospechosos", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
            panel_1.setBounds(259, 55, 550, 290);
            contentPanel.add(panel_1);
            {
                JScrollPane scrollPane = new JScrollPane();
                scrollPane.setBounds(10, 23, 530, 250);
                panel_1.add(scrollPane);
                {
                    tbLista = new JTable();
                    scrollPane.setViewportView(tbLista);
                }
            }
        }
        {
            JButton btnCrearArchivo = new JButton("Crear Archivo ");
            btnCrearArchivo.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Modelo.Sospechoso objeto = new Modelo.Sospechoso();
                    objeto.crearArchivo();
                }
            });
            btnCrearArchivo.setBounds(10, 21, 232, 23);
            contentPanel.add(btnCrearArchivo);
        }
        {
            JButton btnMostrar = new JButton("Mostrar Lista de Sospechosos");
            btnMostrar.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Modelo.Sospechoso objeto = new Modelo.Sospechoso();
                    objeto.MostrarTotal(tbLista);
                }
            });
            btnMostrar.setBounds(261, 21, 234, 23);
            contentPanel.add(btnMostrar);
        }
        {
            JButton btnSeleccionar = new JButton("Seleccionar");
            btnSeleccionar.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Modelo.Sospechoso objeto = new Modelo.Sospechoso();
                    objeto.seleccionar(tbLista);
                    txtId.setText(objeto.getId());
                    txtEdad.setText(objeto.getEdad());
                    txtNombre.setText(objeto.getNombre());
                    txtApellido.setText(objeto.getApellido());
                    txtAlias.setText(objeto.getAlias());
                }
            });
            btnSeleccionar.setBounds(575, 21, 234, 23);
            contentPanel.add(btnSeleccionar);
        }
    }
}
