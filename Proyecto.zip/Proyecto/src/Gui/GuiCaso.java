package Gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

/**
 *
 * @author LEONARDO ACUÑA
 */
public class GuiCaso extends JDialog {

    private final JPanel contentPanel = new JPanel();
    private JTextField txtNumero;
    private JTextField txtDescripcion;
    private JTextField txtCodigo;
    private JTextField txtNombre;
    private JTextField txtTipo;

    private JTable tbLista;

    /**
     * Launch the application.
     *
     * @param args
     */
    public static void main(String[] args) {
        try
        {
            GuiCaso dialog = new GuiCaso();
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            dialog.setVisible(true);

        } catch (Exception e)
        {
        }
    }

    /**
     * Create the dialog.
     */
    public GuiCaso() {
        setBounds(100, 100, 850, 600);
        getContentPane().setLayout(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        getContentPane().add(contentPanel, BorderLayout.CENTER);
        contentPanel.setLayout(null);
        {
            JPanel panel = new JPanel();
            panel.setLayout(null);
            panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Datos del caso", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
            panel.setBounds(10, 55, 239, 490);
            contentPanel.add(panel);
            {
                txtNumero = new JTextField();
                txtNumero.setColumns(10);
                txtNumero.setBounds(132, 24, 92, 20);
                panel.add(txtNumero);
            }
            {
                JLabel lblNewLabel_3 = new JLabel("Numero Caso");
                lblNewLabel_3.setBounds(10, 27, 96, 14);
                panel.add(lblNewLabel_3);
            }
            {
                JLabel lblNewLabel_4 = new JLabel("Descripcion");
                lblNewLabel_4.setBounds(10, 68, 112, 14);
                panel.add(lblNewLabel_4);
            }
            {
                JLabel lblNewLabel_5 = new JLabel("Codigo Prioridad");
                lblNewLabel_5.setBounds(10, 106, 112, 14);
                panel.add(lblNewLabel_5);
            }
            {
                JLabel lblNewLabel_6 = new JLabel("Nombre En Clave");
                lblNewLabel_6.setBounds(10, 147, 162, 14);
                panel.add(lblNewLabel_6);
            }
            {
                JLabel lblNewLabel_6 = new JLabel("Tipo De Caso");
                lblNewLabel_6.setBounds(10, 188, 212, 14);
                panel.add(lblNewLabel_6);
            }

            {
                txtDescripcion = new JTextField();
                txtDescripcion.setColumns(10);
                txtDescripcion.setBounds(132, 65, 92, 20);
                panel.add(txtDescripcion);
            }
            {
                txtCodigo = new JTextField();
                txtCodigo.setColumns(10);
                txtCodigo.setBounds(132, 103, 92, 20);
                panel.add(txtCodigo);
            }
            {
                txtNombre = new JTextField();
                txtNombre.setBounds(132, 147, 92, 20);
                txtNombre.setColumns(10);
                panel.add(txtNombre);
            }
            {
                txtTipo = new JTextField();
                txtTipo.setBounds(132, 185, 92, 20);
                txtTipo.setColumns(10);
                panel.add(txtTipo);
            }

            {
                JButton btnGuardar = new JButton("Guardar");
                btnGuardar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        Modelo.Caso objeto = new Modelo.Caso();
                        objeto.setNumero(txtNumero.getText());
                        objeto.setDescripcion(txtDescripcion.getText());
                        objeto.setCodigo(txtCodigo.getText());
                        objeto.setNombreClave(txtNombre.getText());
                        objeto.setTipo(txtTipo.getText());
                        objeto.agregarRegistros();
                    }
                });
                btnGuardar.setBounds(10, 220, 95, 23);
                panel.add(btnGuardar);
            }
            {
                JButton btnEditar = new JButton("Editar");
                btnEditar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        Modelo.Caso objeto = new Modelo.Caso();
                        objeto.Editar(tbLista);
                    }
                });
                btnEditar.setBounds(135, 220, 90, 23);
                panel.add(btnEditar);
            }
            {
                JButton btnNewButton_1 = new JButton("Agregar Detective");//boton agrega detective
                btnNewButton_1.addActionListener((ActionEvent e) ->
                {
                    GuiDetective objetoDialog = new GuiDetective();
                    objetoDialog.setVisible(rootPaneCheckingEnabled);
                });
                btnNewButton_1.setBounds(10, 300, 215, 23);
                panel.add(btnNewButton_1);
            }
            {
                JButton btnNewButton_2 = new JButton("Agregar Sospechosos");//boton agrega detective
                btnNewButton_2.addActionListener((ActionEvent e) ->
                {
                    GuiSospechosos objetoDialog = new GuiSospechosos();
                    objetoDialog.setVisible(rootPaneCheckingEnabled);
                });
                btnNewButton_2.setBounds(10, 350, 215, 23);
                panel.add(btnNewButton_2);
            }
            {
                JButton btnNewButton_3 = new JButton("Agregar Anotaciones");//boton agrega detective
                btnNewButton_3.addActionListener((ActionEvent e) ->
                {
                    GuiBitacora objetoDialog = new GuiBitacora();
                    objetoDialog.setVisible(rootPaneCheckingEnabled);
                });
                btnNewButton_3.setBounds(10, 400, 215, 23);
                panel.add(btnNewButton_3);
            }
            {
                JButton btnEliminar = new JButton("Eliminar");
                btnEliminar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        Modelo.Caso objetoLibro = new Modelo.Caso();
                        objetoLibro.Eliminar(tbLista, txtNumero);
                    }
                });
                btnEliminar.setBounds(10, 450, 215, 23);
                panel.add(btnEliminar);
            }

        }
        {
            JPanel panel_1 = new JPanel();
            panel_1.setLayout(null);
            panel_1.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Lista de casos", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
            panel_1.setBounds(259, 55, 550, 490);
            contentPanel.add(panel_1);
            {
                JScrollPane scrollPane = new JScrollPane();
                scrollPane.setBounds(10, 23, 530, 450);
                panel_1.add(scrollPane);
                {
                    tbLista = new JTable();
                    scrollPane.setViewportView(tbLista);
                }
            }
        }
        {
            JButton btnCrearArchivo = new JButton("Crear Archivo ");
            btnCrearArchivo.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Modelo.Caso objeto = new Modelo.Caso();
                    objeto.crearArchivo();
                }
            });
            btnCrearArchivo.setBounds(10, 21, 232, 23);
            contentPanel.add(btnCrearArchivo);
        }
        {
            JButton btnMostrar = new JButton("Mostrar Lista de Casos");
            btnMostrar.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Modelo.Caso objeto = new Modelo.Caso();
                    objeto.MostrarTotal(tbLista);
                }
            });
            btnMostrar.setBounds(261, 21, 234, 23);
            contentPanel.add(btnMostrar);
        }
        {
            JButton btnSeleccionar = new JButton("Seleccionar");
            btnSeleccionar.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Modelo.Caso objetoLibro = new Modelo.Caso();

                    objetoLibro.seleccionar(tbLista);
                    txtNumero.setText(objetoLibro.getNumero());
                    txtDescripcion.setText(objetoLibro.getDescripcion());
                    txtCodigo.setText(objetoLibro.getCodigo());
                    txtNombre.setText(objetoLibro.getNombreClave());

                }
            });
            btnSeleccionar.setBounds(555, 21, 234, 23);
            contentPanel.add(btnSeleccionar);
        }
    }

}
