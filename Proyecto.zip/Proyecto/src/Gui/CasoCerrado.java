package Gui;

import java.util.Scanner;
import Modelo.*;

public class CasoCerrado {

    public static void main(String[] args) {
        //int opcion;
        /*Oficina ca1 = new Oficina();
        Detective de1 = new Detective();
        Scanner leer = new Scanner(System.in);
        Bitacora anota1 = new Bitacora();
        Sospechoso sospechoso2 = new Sospechoso();
        Direccion dir1 = new Direccion();

        do
        {
            System.out.println("----------------------------");
            System.out.println("1. Abrir caso");
            System.out.println("2. Consultar casos");
            System.out.println("3. Consultar anotaciones");
            System.out.println("4. Consultar detectives");
            System.out.println("5. Consultar sospechosos");
            System.out.println("6. Eliminar caso");
            System.out.println("7. salir del menu");
            System.out.println("escoja una Opción: ");
            System.out.println("----------------------------");
            opcion = leer.nextInt();
            switch (opcion)
            {
                case 1:
                {
                    ca1.pedirDatos();
                    anota1.pedirAnota();
                    de1.pedirDatosdetec();
                    sospechoso2.pedirDatos();
                    dir1.pedirDatos();

                    break;
                }
                case 2:
                {
                    ca1.imprimir();

                    anota1.imprimir();
                    break;
                }
                case 3:
                {
                    anota1.imprimir();
                    break;
                }
                case 4:
                {
                    de1.imprimir();
                    break;
                }
                case 5:
                {
                    sospechoso2.imprimir();
                    dir1.imprimir();
                    break;
                }
                case 6:
                {
                    ca1.eliminar();
                }
                case 7:
                {
                    System.out.println("PROGRAMA FINALIZADO");
                    break;
                }

            }
        } while (opcion != 7);*/
    }
    
}
