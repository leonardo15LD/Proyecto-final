/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

/**
 *
 * @author LEONARDO ACUÑA
 */
public class GuiDetective extends JDialog{
        private final JPanel contentPanel = new JPanel();
    private JTextField txtIdentificacion;
    private JTextField txtnombre;
    private JTextField txtapellido;
    private JTextField txtAños;
    private JTextField txtTipo;
    private JTable tbLista;

    /**
     * Launch the application.
     *
     * @param args
     */
    public static void main(String[] args) {
        try
        {
            GuiDetective dialog = new GuiDetective();
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            dialog.setVisible(true);

        } catch (Exception e)
        {
        }
    }

    /**
     * Create the dialog.
     */
    public GuiDetective() {
        setBounds(100, 100, 850, 400);
        getContentPane().setLayout(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        getContentPane().add(contentPanel, BorderLayout.CENTER);
        contentPanel.setLayout(null);
        {
            JPanel panel = new JPanel();
            panel.setLayout(null);
            panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Datos De Detectives", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
            panel.setBounds(10, 55, 239, 290);
            contentPanel.add(panel);
            {
                txtIdentificacion = new JTextField();
                txtIdentificacion.setColumns(10);
                txtIdentificacion.setBounds(132, 24, 92, 20);
                panel.add(txtIdentificacion);
            }
            {
                JLabel lblNewLabel_3 = new JLabel("Identificacion");
                lblNewLabel_3.setBounds(10, 27, 96, 14);
                panel.add(lblNewLabel_3);
            }
            {
                JLabel lblNewLabel_4 = new JLabel("Nombres");
                lblNewLabel_4.setBounds(10, 68, 112, 14);
                panel.add(lblNewLabel_4);
            }
            {
                JLabel lblNewLabel_5 = new JLabel("Apellidos");
                lblNewLabel_5.setBounds(10, 106, 112, 14);
                panel.add(lblNewLabel_5);
            }
            {
                JLabel lblNewLabel_6 = new JLabel("Años Experecia");
                lblNewLabel_6.setBounds(10, 147, 162, 14);
                panel.add(lblNewLabel_6);
            }
            {
                JLabel lblNewLabel_7 = new JLabel("Caso Capacitado");
                lblNewLabel_7.setBounds(10, 187, 170, 14);
                panel.add(lblNewLabel_7);
            }

            {
                txtnombre = new JTextField();
                txtnombre.setColumns(10);
                txtnombre.setBounds(132, 65, 92, 20);
                panel.add(txtnombre);
            }
            {
                txtapellido = new JTextField();
                txtapellido.setColumns(10);
                txtapellido.setBounds(132, 103, 92, 20);
                panel.add(txtapellido);
            }
            {
                txtAños = new JTextField();
                txtAños.setBounds(132, 147, 92, 20);
                txtAños.setColumns(10);
                panel.add(txtAños);
            }
            {
                txtTipo = new JTextField();
                txtTipo.setBounds(132, 188, 92, 20);
                txtTipo.setColumns(10);
                panel.add(txtTipo);
            }

            {
                JButton btnGuardar = new JButton("Guardar");
                btnGuardar.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        Modelo.Detective objeto = new Modelo.Detective();
                        objeto.setIdentificacion(txtIdentificacion.getText());
                        objeto.setNombres(txtnombre.getText());
                        objeto.setApellidos(txtapellido.getText());
                        objeto.setAñosExpe(txtAños.getText());
                        objeto.setTipoCaso(txtTipo.getText());
                        objeto.agregarRegistros();
                    }
                });
                btnGuardar.setBounds(10, 220, 95, 23);
                panel.add(btnGuardar);
            }
            {
                JButton btnEditar = new JButton("Editar");
                btnEditar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        Modelo.Detective objeto = new Modelo.Detective();
                        objeto.Editar(tbLista);
                    }
                });
                btnEditar.setBounds(135, 220, 90, 23);
                panel.add(btnEditar);
            }
            {
                JButton btnEliminar = new JButton("Eliminar");
                btnEliminar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        Modelo.Detective objeto = new Modelo.Detective();
                        objeto.Eliminar(tbLista, txtIdentificacion);
                    }
                });
                btnEliminar.setBounds(10, 250, 215, 23);
                panel.add(btnEliminar);
            }

        }
        {
            JPanel panel_1 = new JPanel();
            panel_1.setLayout(null);
            panel_1.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Lista de Detectives", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
            panel_1.setBounds(259, 55, 550, 290);
            contentPanel.add(panel_1);
            {
                JScrollPane scrollPane = new JScrollPane();
                scrollPane.setBounds(10, 23, 530, 250);
                panel_1.add(scrollPane);
                {
                    tbLista = new JTable();
                    scrollPane.setViewportView(tbLista);
                }
            }
        }
        {
            JButton btnCrearArchivo = new JButton("Crear Archivo ");
            btnCrearArchivo.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Modelo.Detective objeto = new Modelo.Detective();
                    objeto.crearArchivo();
                }
            });
            btnCrearArchivo.setBounds(10, 21, 232, 23);
            contentPanel.add(btnCrearArchivo);
        }
        {
            JButton btnMostrar = new JButton("Mostrar Lista de Dectectives");
            btnMostrar.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Modelo.Detective objeto = new Modelo.Detective();
                    objeto.MostrarTotal(tbLista);
                }
            });
            btnMostrar.setBounds(261, 21, 234, 23);
            contentPanel.add(btnMostrar);
        }
        {
            JButton btnSeleccionar = new JButton("Seleccionar");
            btnSeleccionar.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Modelo.Detective objeto = new Modelo.Detective();

                    objeto.seleccionar(tbLista);
                    txtIdentificacion.setText(objeto.getIdentificacion());
                    txtnombre.setText(objeto.getNombres());
                    txtapellido.setText(objeto.getAños());
                    txtAños.setText(objeto.getAños());
                    txtTipo.setText(objeto.getTipoCaso());

                }
            });
            btnSeleccionar.setBounds(570, 21, 234, 23);
            contentPanel.add(btnSeleccionar);
        }
    }
    
}
