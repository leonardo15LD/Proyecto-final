/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

/**
 *
 * @author LEONARDO ACUÑA
 */
public class GuiBitacora extends JDialog{
    private final JPanel contentPanel = new JPanel();
    private JTextField txtFcha;
    private JTextField txtObservaciones;
    
    
    private JTable tbLista;

    /**
     * Launch the application.
     *
     * @param args
     */
    public static void main(String[] args) {
        try
        {
            GuiBitacora dialog = new GuiBitacora();
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            dialog.setVisible(true);

        } catch (Exception e)
        {
        }
    }

    /**
     * Create the dialog.
     */
    public GuiBitacora() {
        setBounds(100, 100, 850, 300);
        getContentPane().setLayout(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        getContentPane().add(contentPanel, BorderLayout.CENTER);
        contentPanel.setLayout(null);
        {
            JPanel panel = new JPanel();
            panel.setLayout(null);
            panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Datos de Observaciones", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
            panel.setBounds(10, 55, 239, 190);
            contentPanel.add(panel);
            {
                txtFcha = new JTextField();
                txtFcha.setColumns(10);
                txtFcha.setBounds(132, 24, 92, 20);
                panel.add(txtFcha);
            }
            {
                JLabel lblNewLabel_3 = new JLabel("Fecha de Registro");
                lblNewLabel_3.setBounds(10, 27, 116, 14);
                panel.add(lblNewLabel_3);
            }
            {
                JLabel lblNewLabel_4 = new JLabel("Observaciones");
                lblNewLabel_4.setBounds(10, 68, 112, 14);
                panel.add(lblNewLabel_4);
            }
          
            {
                txtObservaciones = new JTextField();
                txtObservaciones.setColumns(10);
                txtObservaciones.setBounds(132, 65, 92, 20);
                panel.add(txtObservaciones);
            }
           

            {
                JButton btnGuardar = new JButton("Guardar");
                btnGuardar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        Modelo.Anotaciones objeto = new Modelo.Anotaciones();
                        objeto.setFecha(txtFcha.getText());
                        objeto.setObservaciones(txtObservaciones.getText());
                        objeto.agregarRegistros();
                    }
                });
                btnGuardar.setBounds(10, 120, 95, 23);
                panel.add(btnGuardar);
            }
            {
                JButton btnEditar = new JButton("Editar");
                btnEditar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        Modelo.Anotaciones objeto = new Modelo.Anotaciones();
                        objeto.Editar(tbLista);
                    }
                });
                btnEditar.setBounds(135, 120, 90, 23);
                panel.add(btnEditar);
            }
            {
                JButton btnEliminar = new JButton("Eliminar");
                btnEliminar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        Modelo.Anotaciones objeto = new Modelo.Anotaciones();
                        objeto.Eliminar(tbLista, txtFcha);
                    }
                });
                btnEliminar.setBounds(10, 150, 215, 23);
                panel.add(btnEliminar);
            }

        }
        {
            JPanel panel_1 = new JPanel();
            panel_1.setLayout(null);
            panel_1.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Lista de Observaciones", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
            panel_1.setBounds(259, 55, 550, 190);
            contentPanel.add(panel_1);
            {
                JScrollPane scrollPane = new JScrollPane();
                scrollPane.setBounds(10, 23, 530, 150);
                panel_1.add(scrollPane);
                {
                    tbLista = new JTable();
                    scrollPane.setViewportView(tbLista);
                }
            }
        }
        {
            JButton btnCrearArchivo = new JButton("Crear Archivo ");
            btnCrearArchivo.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Modelo.Anotaciones objeto = new Modelo.Anotaciones();
                    objeto.crearArchivo();
                }
            });
            btnCrearArchivo.setBounds(10, 21, 232, 23);
            contentPanel.add(btnCrearArchivo);
        }
        {
            JButton btnMostrar = new JButton("Mostrar Lista de Observaciones");
            btnMostrar.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Modelo.Anotaciones objeto = new Modelo.Anotaciones();
                    objeto.MostrarTotal(tbLista);
                }
            });
            btnMostrar.setBounds(261, 21, 234, 23);
            contentPanel.add(btnMostrar);
        }
        {
            JButton btnSeleccionar = new JButton("Seleccionar");
            btnSeleccionar.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Modelo.Anotaciones objeto = new Modelo.Anotaciones();

                    objeto.seleccionar(tbLista);
                    txtFcha.setText(objeto.getFecha());
                    txtObservaciones.setText(objeto.getObservaciones());

                }
            });
            btnSeleccionar.setBounds(570, 21, 234, 23);
            contentPanel.add(btnSeleccionar);
        }
    }
}
