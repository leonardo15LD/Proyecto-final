
package Modelo;

import javax.swing.JTable;
import javax.swing.JTextField;

/**
 *
 * @author LEONARDO ACUÑA
 */
public interface Imetodos {
    void crearArchivo();
    void agregarRegistros();
    void MostrarTotal(JTable tablaTotal);
    void Eliminar(JTable tablaLibros, JTextField codigo);
}
