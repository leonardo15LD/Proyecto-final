package Modelo;

import java.awt.HeadlessException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringJoiner;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Caso implements Imetodos{

    private String numero;

    private String descripcion, codigo, nombreClave,tipo;

    private Detective detectives;//relacion de agregacion

    public Caso() {
    }

    public Caso(String numero, String descripcion, String codigo, String nombreClave,String tipo) {
        this.numero = numero;
        this.descripcion = descripcion;
        this.codigo = codigo;
        this.nombreClave = nombreClave;
        this.tipo=tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombreClave() {
        return nombreClave;
    }

    public void setNombreClave(String nombreClave) {
        this.nombreClave = nombreClave;
    }

    public Detective getDetectives() {
        return detectives;
    }

    public void setDetectives(Detective detectives) {
        this.detectives = detectives;
    }
    @Override
    public void crearArchivo() {
        try
        {
            File objetoArchivo = new File("Casos.txt");
            if (objetoArchivo.createNewFile())
            {
                JOptionPane.showMessageDialog(null, "Se ha creado correctamenteo el archivo" + objetoArchivo.getName());
            } else
            {
                JOptionPane.showMessageDialog(null, "El archivo ya existe");
            }

        } catch (Exception e)
        {
            System.out.println("Ocurrio un error al crear el archivo");

        }
    }

    @Override
    public void agregarRegistros() {
        try
        {
            FileWriter fw = new FileWriter("Casos.txt", true);
            fw.write(getNumero());
            fw.write(",");
            fw.write(getDescripcion());
            fw.write(",");
            fw.write(getCodigo());
            fw.write(",");
            fw.write(getNombreClave());
            fw.write(",");
            fw.write(getTipo());
            fw.write("\n");
            fw.close();

            JOptionPane.showMessageDialog(null, "Se registro correctamente");
        } catch (HeadlessException | IOException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error al registrar" + e.toString());
        }
    }

    @Override
    public void MostrarTotal(JTable tablaTotal) {

        String nombreArchivo = "Casos.txt";

        File file = new File(nombreArchivo);

        try
        {

            BufferedReader br = new BufferedReader(new FileReader(file));

            String primeraLinea = br.readLine().trim();

            DefaultTableModel model = new DefaultTableModel();

            model.addColumn("NUMERO CASO");
            model.addColumn("DESCRIPCION");
            model.addColumn("CODIGO PRIORIDAD");
            model.addColumn("NOMBRE EN CLAVE");
            model.addColumn("TIPO DE CASO");
     
            tablaTotal.setModel(model);

            Object[] tableLines = br.lines().toArray();

            for (Object tableLine : tableLines)
            {
                String line = tableLine.toString().trim();
                String[] datarow = line.split(",");
                model.addRow(datarow);
                tablaTotal.setModel(model);
            }

        } catch (IOException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error" + e.toString());

        }
    }
    public void seleccionar(JTable tabla) {

        try
        {

            int fila = tabla.getSelectedRow();

            if (fila >= 0)
            {

                setNumero(tabla.getValueAt(fila, 0).toString());
                setDescripcion(tabla.getValueAt(fila, 1).toString());
                setCodigo(tabla.getValueAt(fila, 2).toString());
                setNombreClave(tabla.getValueAt(fila, 3).toString());
                setTipo(tabla.getValueAt(fila, 4).toString());
                
            }

        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error" + e.toString());
        }

    }
    
    @Override
    public void Eliminar(JTable tabla, JTextField codigo) {

        //Eliminaci�n visual de la tabla
        DefaultTableModel model = (DefaultTableModel) tabla.getModel();

        for (int i = 0; i < model.getRowCount(); i++)
        {

            if (((String) model.getValueAt(i, 0)).equals(codigo.getText()))
            {
                model.removeRow(i);
                break;

            }
        }
        //Limpieza del archivo .txt

        try
        {
            PrintWriter writer = new PrintWriter("Casos.txt");
            writer.print("");
            writer.close();
        } catch (FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un problema" + e.toString());
        }

        //Creaci�n de los nuevos registros luego de la eliminaci�n
        try ( BufferedWriter bw = new BufferedWriter(new FileWriter(new File("AudioLibro.txt"))))
        {
            StringJoiner joiner = new StringJoiner(",");

            for (int col = 0; col < tabla.getColumnCount(); col++)
            {
                joiner.add(tabla.getColumnName(col));
            }

            System.out.println(joiner.toString());
            bw.write(joiner.toString());
            bw.newLine();

            for (int row = 0; row < tabla.getRowCount(); row++)
            {
                joiner = new StringJoiner(",");
                for (int col = 0; col < tabla.getColumnCount(); col++)
                {

                    Object obj = tabla.getValueAt(row, col);
                    String value = obj == null ? "null" : obj.toString();
                    joiner.add(value);

                }

                bw.write(joiner.toString());
                bw.newLine();
                JOptionPane.showMessageDialog(null, "Se elimino correctamente");
            }

        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error");
        }

    }

    public void Editar(JTable tabla) {

        //Limpieza del archivo .txt
        try
        {
            PrintWriter writer = new PrintWriter("Casos.txt");
            writer.print("");
            writer.close();
        } catch (FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un problema" + e.toString());
        }

        //Creaci�n de los nuevos registros luego de la eliminaci�n
        try ( BufferedWriter bw = new BufferedWriter(new FileWriter(new File("AudioLibro.txt"))))
        {
            StringJoiner joiner = new StringJoiner(",");
            for (int col = 0; col < tabla.getColumnCount(); col++)
            {
                joiner.add(tabla.getColumnName(col));
            }

            System.out.println(joiner.toString());
            bw.write(joiner.toString());
            bw.newLine();

            for (int row = 0; row < tabla.getRowCount(); row++)
            {
                joiner = new StringJoiner(",");
                for (int col = 0; col < tabla.getColumnCount(); col++)
                {

                    Object obj = tabla.getValueAt(row, col);
                    String value = obj == null ? "null" : obj.toString();
                    joiner.add(value);

                }

                System.out.println(joiner.toString());
                bw.write(joiner.toString());
                bw.newLine();
                //JOptionPane.showMessageDialog(null, "Se modifico correctamente");
            }

        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error");
        }

    }

}
