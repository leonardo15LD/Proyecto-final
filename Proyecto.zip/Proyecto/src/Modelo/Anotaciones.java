package Modelo;

import java.awt.HeadlessException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringJoiner;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Anotaciones implements Imetodos {

    private String fecha, observaciones;

    public Anotaciones(String fecha, String observaciones) {
        this.fecha = fecha;
        this.observaciones = observaciones;
    }

    public Anotaciones() {
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    @Override
    public void crearArchivo() {
        try
        {
            File objetoArchivo = new File("Anotaciones.txt");
            if (objetoArchivo.createNewFile())
            {
                JOptionPane.showMessageDialog(null, "Se ha creado correctamenteo el archivo" + objetoArchivo.getName());
            } else
            {
                JOptionPane.showMessageDialog(null, "El archivo ya existe");
            }

        } catch (HeadlessException | IOException e)
        {
            System.out.println("Ocurrio un error al crear el archivo");

        }
    }

    @Override
    public void agregarRegistros() {
        try
        {
            FileWriter fw = new FileWriter("Anotaciones.txt", true);
            fw.write(getFecha());
            fw.write(",");
            fw.write(getObservaciones());
            fw.write("\n");
            fw.close();

            JOptionPane.showMessageDialog(null, "Se registro correctamente");
        } catch (HeadlessException | IOException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error al registrar" + e.toString());
        }
    }

    @Override
    public void MostrarTotal(JTable tablaTotal) {

        String nombreArchivo = "Anotaciones.txt";

        File file = new File(nombreArchivo);

        try
        {

            BufferedReader br = new BufferedReader(new FileReader(file));

            String primeraLinea = br.readLine().trim();

            DefaultTableModel model = new DefaultTableModel();

            model.addColumn("FECHA");
            model.addColumn("OBSERVACION");

            tablaTotal.setModel(model);

            Object[] tableLines = br.lines().toArray();

            for (Object tableLine : tableLines)
            {
                String line = tableLine.toString().trim();
                String[] datarow = line.split(",");
                model.addRow(datarow);
                tablaTotal.setModel(model);
            }

        } catch (IOException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error" + e.toString());

        }
    }

    public void seleccionar(JTable tabla) {

        try
        {

            int fila = tabla.getSelectedRow();

            if (fila >= 0)
            {

                setFecha(tabla.getValueAt(fila, 0).toString());
                setObservaciones(tabla.getValueAt(fila, 1).toString());

            }

        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error" + e.toString());
        }

    }

    @Override
    public void Eliminar(JTable tabla, JTextField codigo) {

        //Eliminaci�n visual de la tabla
        DefaultTableModel model = (DefaultTableModel) tabla.getModel();

        for (int i = 0; i < model.getRowCount(); i++)
        {

            if (((String) model.getValueAt(i, 0)).equals(codigo.getText()))
            {
                model.removeRow(i);
                break;

            }
        }
        //Limpieza del archivo .txt

        try
        {
            PrintWriter writer = new PrintWriter("Anotaciones.txt");
            writer.print("");
            writer.close();
        } catch (FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un problema" + e.toString());
        }

        //Creaci�n de los nuevos registros luego de la eliminaci�n
        try ( BufferedWriter bw = new BufferedWriter(new FileWriter(new File("Anotaciones.txt"))))
        {
            StringJoiner joiner = new StringJoiner(",");

            for (int col = 0; col < tabla.getColumnCount(); col++)
            {
                joiner.add(tabla.getColumnName(col));
            }

            System.out.println(joiner.toString());
            bw.write(joiner.toString());
            bw.newLine();

            for (int row = 0; row < tabla.getRowCount(); row++)
            {
                joiner = new StringJoiner(",");
                for (int col = 0; col < tabla.getColumnCount(); col++)
                {

                    Object obj = tabla.getValueAt(row, col);
                    String value = obj == null ? "null" : obj.toString();
                    joiner.add(value);

                }

                bw.write(joiner.toString());
                bw.newLine();
                JOptionPane.showMessageDialog(null, "Se elimino correctamente");
            }

        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error");
        }

    }

    public void Editar(JTable tabla) {

        //Limpieza del archivo .txt
        try
        {
            PrintWriter writer = new PrintWriter("Anotaciones.txt");
            writer.print("");
            writer.close();
        } catch (FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un problema" + e.toString());
        }

        //Creaci�n de los nuevos registros luego de la eliminaci�n
        try ( BufferedWriter bw = new BufferedWriter(new FileWriter(new File("Anotaciones.txt"))))
        {
            StringJoiner joiner = new StringJoiner(",");
            for (int col = 0; col < tabla.getColumnCount(); col++)
            {
                joiner.add(tabla.getColumnName(col));
            }

            System.out.println(joiner.toString());
            bw.write(joiner.toString());
            bw.newLine();

            for (int row = 0; row < tabla.getRowCount(); row++)
            {
                joiner = new StringJoiner(",");
                for (int col = 0; col < tabla.getColumnCount(); col++)
                {

                    Object obj = tabla.getValueAt(row, col);
                    String value = obj == null ? "null" : obj.toString();
                    joiner.add(value);

                }

                System.out.println(joiner.toString());
                bw.write(joiner.toString());
                bw.newLine();
                //JOptionPane.showMessageDialog(null, "Se modifico correctamente");
            }

        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error");
        }

    }

}
