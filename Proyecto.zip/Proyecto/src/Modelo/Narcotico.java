package Modelo;
import java.util.Scanner;
public class Narcotico extends Caso{

    String tipoNarcotico;
    Detective dectective;
    Scanner leer2 = new Scanner(System.in);

    public String getTipoNarcotico() {
        return tipoNarcotico;
    }

    public void setTipoNarcotico(String tipoNarcotico) {
        this.tipoNarcotico = tipoNarcotico;
    }

    public Detective getDectective() {
        return dectective;
    }

    public void setDectective(Detective dectective) {
        this.dectective = dectective;
    }

    public Narcotico() {
    }

    public Narcotico(String tipoNarcotico, Detective dectective) {
        this.tipoNarcotico = tipoNarcotico;
        this.dectective = dectective;
    }

    

}
