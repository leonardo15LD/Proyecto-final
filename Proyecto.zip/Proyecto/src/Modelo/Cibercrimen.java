package Modelo;
import java.util.Scanner;
public class Cibercrimen extends Caso{

    String ciberAso;
    Detective dectective;
    Scanner leer = new Scanner(System.in);
    public Cibercrimen() {
    }

    public String getCiberAso() {
        return ciberAso;
    }

    public void setCiberAso(String ciberAso) {
        this.ciberAso = ciberAso;
    }

    public Detective getDectective() {
        return dectective;
    }

    public void setDectective(Detective dectective) {
        this.dectective = dectective;
    }

    public Cibercrimen(String ciberAso, Detective dectective) {
        this.ciberAso = ciberAso;
        this.dectective = dectective;
    }

    

}
