package Modelo;

import java.awt.HeadlessException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringJoiner;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Detective implements Imetodos {

    private String identificacion;
    private String nombres, apellidos, años;
    private String tipoCaso;

    public Detective() {
    }

    public Detective(String identificacion, String nombres, String apellidos, String años, String tipoCaso) {
        this.identificacion = identificacion;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.años = años;
        this.tipoCaso = tipoCaso;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getAños() {
        return años;
    }

    public void setAñosExpe(String añosExpe) {
        this.años = añosExpe;
    }

    public String getTipoCaso() {
        return tipoCaso;
    }

    public void setTipoCaso(String tipoCaso) {
        this.tipoCaso = tipoCaso;
    }

    @Override
    public void crearArchivo() {
        try
        {
            File objetoArchivo = new File("Detective.txt");
            if (objetoArchivo.createNewFile())
            {
                JOptionPane.showMessageDialog(null, "Se ha creado correctamenteo el archivo" + objetoArchivo.getName());
            } else
            {
                JOptionPane.showMessageDialog(null, "El archivo ya existe");
            }

        } catch (Exception e)
        {
            System.out.println("Ocurrio un error al crear el archivo");

        }
    }

    @Override
    public void agregarRegistros() {
        try
        {
            FileWriter fw = new FileWriter("Detective.txt", true);
            fw.write(getIdentificacion());
            fw.write(",");
            fw.write(getNombres());
            fw.write(",");
            fw.write(getApellidos());
            fw.write(",");
            fw.write(getAños());
            fw.write(",");
            fw.write(getAños());
            fw.write(",");
            fw.write(getTipoCaso());
            fw.write("\n");
            fw.close();

            JOptionPane.showMessageDialog(null, "Se registro correctamente");
        } catch (HeadlessException | IOException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error al registrar" + e.toString());
        }
    }

    @Override
    public void MostrarTotal(JTable tablaTotal) {

        String nombreArchivo = "Detective.txt";

        File file = new File(nombreArchivo);

        try
        {

            BufferedReader br = new BufferedReader(new FileReader(file));

            String primeraLinea = br.readLine().trim();

            DefaultTableModel model = new DefaultTableModel();

            model.addColumn("IDENTIFICACION");
            model.addColumn("NOMBRES");
            model.addColumn("APELLIDOS");
            model.addColumn("AÑOS EXPERIENCIA");
            model.addColumn("TIPO DE CASO CAPACITADO");

            tablaTotal.setModel(model);

            Object[] tableLines = br.lines().toArray();

            for (Object tableLine : tableLines)
            {
                String line = tableLine.toString().trim();
                String[] datarow = line.split(",");
                model.addRow(datarow);
                tablaTotal.setModel(model);
            }

        } catch (IOException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error" + e.toString());

        }
    }

    public void seleccionar(JTable tabla) {

        try
        {

            int fila = tabla.getSelectedRow();

            if (fila >= 0)
            {

                setIdentificacion(tabla.getValueAt(fila, 0).toString());
                setNombres(tabla.getValueAt(fila, 1).toString());
                setApellidos(tabla.getValueAt(fila, 2).toString());
                setAñosExpe(tabla.getValueAt(fila, 3).toString());
                setTipoCaso(tabla.getValueAt(fila, 4).toString());
            }

        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error" + e.toString());
        }

    }

    @Override
    public void Eliminar(JTable tablaLibros, JTextField codigoLibro) {

        //Eliminaci�n visual de la tabla
        DefaultTableModel model = (DefaultTableModel) tablaLibros.getModel();

        for (int i = 0; i < model.getRowCount(); i++)
        {

            if (((String) model.getValueAt(i, 0)).equals(codigoLibro.getText()))
            {
                model.removeRow(i);
                break;

            }
        }
        //Limpieza del archivo .txt

        try
        {
            PrintWriter writer = new PrintWriter("Detective.txt");
            writer.print("");
            writer.close();
        } catch (FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un problema" + e.toString());
        }

        //Creaci�n de los nuevos registros luego de la eliminaci�n
        try ( BufferedWriter bw = new BufferedWriter(new FileWriter(new File("AudioLibro.txt"))))
        {
            StringJoiner joiner = new StringJoiner(",");

            for (int col = 0; col < tablaLibros.getColumnCount(); col++)
            {
                joiner.add(tablaLibros.getColumnName(col));
            }

            System.out.println(joiner.toString());
            bw.write(joiner.toString());
            bw.newLine();

            for (int row = 0; row < tablaLibros.getRowCount(); row++)
            {
                joiner = new StringJoiner(",");
                for (int col = 0; col < tablaLibros.getColumnCount(); col++)
                {

                    Object obj = tablaLibros.getValueAt(row, col);
                    String value = obj == null ? "null" : obj.toString();
                    joiner.add(value);

                }

                bw.write(joiner.toString());
                bw.newLine();
                JOptionPane.showMessageDialog(null, "Se elimino correctamente");
            }

        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error");
        }

    }

    public void Editar(JTable tabla) {

        //Limpieza del archivo .txt
        try
        {
            PrintWriter writer = new PrintWriter("Detective.txt");
            writer.print("");
            writer.close();
        } catch (FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un problema" + e.toString());
        }

        //Creaci�n de los nuevos registros luego de la eliminaci�n
        try ( BufferedWriter bw = new BufferedWriter(new FileWriter(new File("AudioLibro.txt"))))
        {
            StringJoiner joiner = new StringJoiner(",");
            for (int col = 0; col < tabla.getColumnCount(); col++)
            {
                joiner.add(tabla.getColumnName(col));
            }

            System.out.println(joiner.toString());
            bw.write(joiner.toString());
            bw.newLine();

            for (int row = 0; row < tabla.getRowCount(); row++)
            {
                joiner = new StringJoiner(",");
                for (int col = 0; col < tabla.getColumnCount(); col++)
                {

                    Object obj = tabla.getValueAt(row, col);
                    String value = obj == null ? "null" : obj.toString();
                    joiner.add(value);

                }

                System.out.println(joiner.toString());
                bw.write(joiner.toString());
                bw.newLine();
                //JOptionPane.showMessageDialog(null, "Se modifico correctamente");
            }

        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error");
        }

    }

}
