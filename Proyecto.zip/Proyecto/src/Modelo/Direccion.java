package Modelo;

import java.awt.HeadlessException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringJoiner;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Direccion implements Imetodos{

    
    private String noVivienda;
    private String localidad, ciudad, departamento, pais, caracteristicas;

    public Direccion() {
    }
    
    

    public Direccion(String noVivienda, String localidad, String ciudad, String departamento, String pais, String caracteristicas) {
        this.noVivienda = noVivienda;
        this.localidad = localidad;
        this.ciudad = ciudad;
        this.departamento = departamento;
        this.pais = pais;
        this.caracteristicas = caracteristicas;
    }

    public String getNoVivienda() {
        return noVivienda;
    }

    public void setNoVivienda(String noVivienda) {
        this.noVivienda = noVivienda;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getCaracteristicas() {
        return caracteristicas;
    }

    public void setCaracteristicas(String caracteristicas) {
        this.caracteristicas = caracteristicas;
    }
    @Override
    public void crearArchivo() {
        try
        {
            File objetoArchivo = new File("Direccion.txt");
            if (objetoArchivo.createNewFile())
            {
                JOptionPane.showMessageDialog(null, "Se ha creado correctamenteo el archivo" + objetoArchivo.getName());
            } else
            {
                JOptionPane.showMessageDialog(null, "El archivo ya existe");
            }

        } catch (HeadlessException | IOException e)
        {
            System.out.println("Ocurrio un error al crear el archivo");

        }
    }

    @Override
    public void agregarRegistros() {
        try
        {
            FileWriter fw = new FileWriter("Direccion.txt", true);
            fw.write(getNoVivienda());
            fw.write(",");
            fw.write(getLocalidad());
            fw.write(",");
            fw.write(getCiudad());
            fw.write(",");
            fw.write(getDepartamento());
            fw.write(",");
            fw.write(getPais());
            fw.write(",");
            fw.write(getCaracteristicas());
            fw.write("\n");
            fw.close();

            JOptionPane.showMessageDialog(null, "Se registro correctamente");
        } catch (HeadlessException | IOException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error al registrar" + e.toString());
        }
    }

    @Override
    public void MostrarTotal(JTable tablaTotal) {

        String nombreArchivo = "Direccion.txt";

        File file = new File(nombreArchivo);

        try
        {

            BufferedReader br = new BufferedReader(new FileReader(file));

            String primeraLinea = br.readLine().trim();

            DefaultTableModel model = new DefaultTableModel();

            model.addColumn("NUMERO VIVIENDA");
            model.addColumn("LOCALIDAD");
            model.addColumn("CIUDAD");
            model.addColumn("DEPARTAMENTO");
            model.addColumn("PAIS");
            model.addColumn("CARACTERISTICAS");

            tablaTotal.setModel(model);

            Object[] tableLines = br.lines().toArray();

            for (Object tableLine : tableLines)
            {
                String line = tableLine.toString().trim();
                String[] datarow = line.split(",");
                model.addRow(datarow);
                tablaTotal.setModel(model);
            }

        } catch (IOException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error" + e.toString());

        }
    }

    public void seleccionar(JTable tabla) {

        try
        {

            int fila = tabla.getSelectedRow();

            if (fila >= 0)
            {

                setNoVivienda(tabla.getValueAt(fila, 0).toString());
                setLocalidad(tabla.getValueAt(fila, 1).toString());
                
                setCiudad(tabla.getValueAt(fila, 2).toString());
                setDepartamento(tabla.getValueAt(fila, 3).toString());
                setPais(tabla.getValueAt(fila, 4).toString());
                setCaracteristicas(tabla.getValueAt(fila, 5).toString());
            }

        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error" + e.toString());
        }

    }

    @Override
    public void Eliminar(JTable tabla, JTextField codigo) {

        //Eliminaci�n visual de la tabla
        DefaultTableModel model = (DefaultTableModel) tabla.getModel();

        for (int i = 0; i < model.getRowCount(); i++)
        {

            if (((String) model.getValueAt(i, 0)).equals(codigo.getText()))
            {
                model.removeRow(i);
                break;

            }
        }
        //Limpieza del archivo .txt

        try
        {
            PrintWriter writer = new PrintWriter("Direccion.txt");
            writer.print("");
            writer.close();
        } catch (FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un problema" + e.toString());
        }

        //Creaci�n de los nuevos registros luego de la eliminaci�n
        try ( BufferedWriter bw = new BufferedWriter(new FileWriter(new File("Sospechosos.txt"))))
        {
            StringJoiner joiner = new StringJoiner(",");

            for (int col = 0; col < tabla.getColumnCount(); col++)
            {
                joiner.add(tabla.getColumnName(col));
            }

            System.out.println(joiner.toString());
            bw.write(joiner.toString());
            bw.newLine();

            for (int row = 0; row < tabla.getRowCount(); row++)
            {
                joiner = new StringJoiner(",");
                for (int col = 0; col < tabla.getColumnCount(); col++)
                {

                    Object obj = tabla.getValueAt(row, col);
                    String value = obj == null ? "null" : obj.toString();
                    joiner.add(value);

                }

                bw.write(joiner.toString());
                bw.newLine();
                JOptionPane.showMessageDialog(null, "Se elimino correctamente");
            }

        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error");
        }

    }

    public void Editar(JTable tabla) {

        //Limpieza del archivo .txt
        try
        {
            PrintWriter writer = new PrintWriter("Direccion.txt");
            writer.print("");
            writer.close();
        } catch (FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un problema" + e.toString());
        }

        //Creaci�n de los nuevos registros luego de la eliminaci�n
        try ( BufferedWriter bw = new BufferedWriter(new FileWriter(new File("Sospechosos.txt"))))
        {
            StringJoiner joiner = new StringJoiner(",");
            for (int col = 0; col < tabla.getColumnCount(); col++)
            {
                joiner.add(tabla.getColumnName(col));
            }

            System.out.println(joiner.toString());
            bw.write(joiner.toString());
            bw.newLine();

            for (int row = 0; row < tabla.getRowCount(); row++)
            {
                joiner = new StringJoiner(",");
                for (int col = 0; col < tabla.getColumnCount(); col++)
                {

                    Object obj = tabla.getValueAt(row, col);
                    String value = obj == null ? "null" : obj.toString();
                    joiner.add(value);

                }

                System.out.println(joiner.toString());
                bw.write(joiner.toString());
                bw.newLine();
                //JOptionPane.showMessageDialog(null, "Se modifico correctamente");
            }

        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error");
        }

    }
    

}
